# Overview 
Phemus is a software tool aimed to provide fairness assessment and improvement for machine learning datasets.

# Credit
This work is based on the technology developed in the following conference proceeding:

title: Automated directed fairness testing}

author: Udeshi, Sakshi and Arora, Pryanshu and Chattopadhyay, Sudipta

booktitle: Proceedings of the 33rd ACM/IEEE International Conference on Automated Software Engineering

pages: 98--108

year: 2018

Liscened by the original authors